#!/usr/bin/env python3
"""
Plutonium Linux Client & Management Suite (v1.4.4)
A fully-fledged standalone native Linux desktop GUI application for Call of Duty custom clients.
Includes interactive Game Launcher, Steam Auto-Scanner, Proton/Wine Manager, Live Master Server
Browser with 1-click connect, Mod & GSC Manager, and Desktop Integration.
"""

import os
import sys
import json
import shutil
import urllib.request
import urllib.error
import subprocess
import threading
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Tuple

VERSION = "1.4.4"
PLUTONIUM_API_URL = "https://plutonium.pw/api/servers"
PLUTONIUM_EXE_URL = "https://cdn.plutonium.pw/updater/plutonium.exe"

SUPPORTED_GAMES = {
    "t6zm": {
        "title": "Call of Duty: Black Ops II (Zombies)",
        "game_id": "t6",
        "mode": "zm",
        "exe_names": ["t6zm.exe"],
        "default_dir": "Call of Duty Black Ops II",
        "description": "Zombies mod supporting custom GSC scripts, server browser, Tranzit, Die Rise, Mob of the Dead, Buried, Origins."
    },
    "t6mp": {
        "title": "Call of Duty: Black Ops II (Multiplayer)",
        "game_id": "t6",
        "mode": "mp",
        "exe_names": ["t6mp.exe", "t6mpv.exe"],
        "default_dir": "Call of Duty Black Ops II",
        "description": "Multiplayer client with dedicated servers, theater fixes, unlock all, and balanced weaponry."
    },
    "iw5mp": {
        "title": "Call of Duty: Modern Warfare 3 (Multiplayer)",
        "game_id": "iw5",
        "mode": "mp",
        "exe_names": ["iw5mp.exe"],
        "default_dir": "Call of Duty Modern Warfare 3",
        "description": "Modern Warfare 3 dedicated servers with unranked/ranked server browser and security patches."
    },
    "t4sp": {
        "title": "Call of Duty: World at War (Co-op / Zombies)",
        "game_id": "t4",
        "mode": "sp",
        "exe_names": ["CoDWaW.exe"],
        "default_dir": "Call of Duty World at War",
        "description": "WaW campaign and legendary custom Nazi Zombies mod map loading with fix for modern systems."
    },
    "t4mp": {
        "title": "Call of Duty: World at War (Multiplayer)",
        "game_id": "t4",
        "mode": "mp",
        "exe_names": ["CoDWaWmp.exe"],
        "default_dir": "Call of Duty World at War",
        "description": "World at War multiplayer with master server fixes, punkbuster removal, and custom servers."
    },
    "t5sp": {
        "title": "Call of Duty: Black Ops (Zombies)",
        "game_id": "t5",
        "mode": "sp",
        "exe_names": ["BlackOps.exe", "t5sp.exe"],
        "default_dir": "Call of Duty Black Ops",
        "description": "Black Ops 1 zombies with Kino der Toten, Five, Ascension, Call of the Dead, Shangri-La, Moon."
    },
    "t5mp": {
        "title": "Call of Duty: Black Ops (Multiplayer)",
        "game_id": "t5",
        "mode": "mp",
        "exe_names": ["BlackOpsMP.exe", "t5mp.exe"],
        "default_dir": "Call of Duty Black Ops",
        "description": "Black Ops 1 multiplayer with custom dedicated servers and combat training bots."
    }
}

class LinuxClientConfig:
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or (Path.home() / ".config" / "plutonium-linux")
        self.config_file = self.config_dir / "config.json"
        self.games_file = self.config_dir / "games.json"
        self.data_dir = Path.home() / ".local" / "share" / "plutonium-linux"
        self.prefix_dir = self.data_dir / "wineprefix"
        self.plutonium_dir = self.data_dir / "plutonium_bin"
        
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.prefix_dir.mkdir(parents=True, exist_ok=True)
        self.plutonium_dir.mkdir(parents=True, exist_ok=True)
        
        self.settings = self.load_settings()
        self.games = self.load_games()

    def load_settings(self) -> dict:
        default_settings = {
            "runner_type": "auto",
            "custom_runner_bin": "",
            "dxvk_enabled": True,
            "esync": True,
            "fsync": True,
            "offline_lan_safety": True,
            "mesa_gl_override": "4.5"
        }
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    default_settings.update(data)
            except Exception:
                pass
        return default_settings

    def save_settings(self):
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(self.settings, f, indent=2)

    def load_games(self) -> dict:
        if self.games_file.exists():
            try:
                with open(self.games_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def save_games(self):
        with open(self.games_file, "w", encoding="utf-8") as f:
            json.dump(self.games, f, indent=2)

class RunnerManager:
    @staticmethod
    def find_all_runners() -> List[Dict[str, str]]:
        runners = []
        home = Path.home()
        
        custom_proton_dirs = [
            home / ".local" / "share" / "Steam" / "compatibilitytools.d",
            home / ".steam" / "root" / "compatibilitytools.d",
            home / ".steam" / "steam" / "compatibilitytools.d",
        ]
        for cdir in custom_proton_dirs:
            if cdir.exists():
                for p in sorted(cdir.iterdir(), reverse=True):
                    if p.is_dir() and (p / "proton").exists():
                        runners.append({
                            "name": f"GE-Proton ({p.name})",
                            "type": "proton",
                            "path": str(p / "proton"),
                            "base_dir": str(p)
                        })

        steam_common_dirs = [
            home / ".local" / "share" / "Steam" / "steamapps" / "common",
            home / ".steam" / "steam" / "steamapps" / "common",
            home / ".var" / "app" / "com.valvesoftware.Steam" / ".local" / "share" / "Steam" / "steamapps" / "common",
        ]
        for sdir in steam_common_dirs:
            if sdir.exists():
                for p in sorted(sdir.glob("Proton*"), reverse=True):
                    if p.is_dir() and (p / "proton").exists():
                        runners.append({
                            "name": f"Steam Proton ({p.name})",
                            "type": "proton",
                            "path": str(p / "proton"),
                            "base_dir": str(p)
                        })

        lutris_wine_dir = home / ".local" / "share" / "lutris" / "runners" / "wine"
        if lutris_wine_dir.exists():
            for p in sorted(lutris_wine_dir.iterdir(), reverse=True):
                wine_bin = p / "bin" / "wine"
                if wine_bin.exists():
                    runners.append({
                        "name": f"Lutris Wine ({p.name})",
                        "type": "wine",
                        "path": str(wine_bin),
                        "base_dir": str(p)
                    })

        system_wine = shutil.which("wine")
        if system_wine:
            runners.append({
                "name": "System Wine",
                "type": "wine",
                "path": system_wine,
                "base_dir": str(Path(system_wine).parent.parent)
            })

        return runners

    @classmethod
    def get_best_runner(cls, preferred: str = "auto") -> Optional[Dict[str, str]]:
        runners = cls.find_all_runners()
        if not runners:
            return None
        if preferred != "auto":
            for r in runners:
                if preferred.lower() in r["name"].lower() or preferred.lower() in r["type"].lower() or preferred == r["path"]:
                    return r
        for r in runners:
            if "ge-proton" in r["name"].lower():
                return r
        for r in runners:
            if "steam proton" in r["name"].lower():
                return r
        return runners[0]

class GameDiscovery:
    COMMON_STEAM_PATHS = [
        Path.home() / ".local/share/Steam",
        Path.home() / ".steam/steam",
        Path.home() / ".var/app/com.valvesoftware.Steam/.local/share/Steam",
        Path("/media"),
        Path("/mnt")
    ]

    @classmethod
    def find_steam_libraries(cls) -> List[Path]:
        libraries = []
        for base in cls.COMMON_STEAM_PATHS:
            if not base.exists():
                continue
            common = base / "steamapps" / "common"
            if common.exists():
                libraries.append(common)
            vdf_path = base / "steamapps" / "libraryfolders.vdf"
            if vdf_path.exists():
                try:
                    with open(vdf_path, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            if '"path"' in line:
                                parts = line.split('"path"')
                                if len(parts) > 1:
                                    raw_path = parts[1].strip().strip('"').replace('\\\\', '/')
                                    lib_common = Path(raw_path) / "steamapps" / "common"
                                    if lib_common.exists() and lib_common not in libraries:
                                        libraries.append(lib_common)
                except Exception:
                    pass
        return libraries

    @classmethod
    def auto_detect_games(cls) -> Dict[str, str]:
        detected = {}
        libs = cls.find_steam_libraries()
        for key, info in SUPPORTED_GAMES.items():
            for lib in libs:
                candidate = lib / info["default_dir"]
                if candidate.exists():
                    for exe in info["exe_names"]:
                        if (candidate / exe).exists():
                            detected[key] = str(candidate)
                            break
                    if key in detected:
                        break
        return detected

class PlutoniumManager:
    def __init__(self, config: LinuxClientConfig):
        self.config = config
        self.active_process = None

    def download_plutonium_exe(self) -> bool:
        target = self.config.plutonium_dir / "plutonium.exe"
        if target.exists() and target.stat().st_size > 100000:
            return True
        try:
            req = urllib.request.Request(
                PLUTONIUM_EXE_URL,
                headers={"User-Agent": "PlutoniumLinuxClient/1.4"}
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                with open(target, "wb") as f:
                    f.write(resp.read())
            return True
        except Exception:
            return False

    def get_wine_env(self, runner: Dict[str, str]) -> Dict[str, str]:
        env = os.environ.copy()
        env["WINEPREFIX"] = str(self.config.prefix_dir)
        env["WINEARCH"] = "win64"
        env["WINEDLLOVERRIDES"] = "d3dcompiler_43,d3dcompiler_47,d3dx9_43=n,b;mscoree,mshtml="
        env["MESA_GL_VERSION_OVERRIDE"] = self.config.settings.get("mesa_gl_override", "4.5")
        
        if self.config.settings.get("esync", True):
            env["WINEESYNC"] = "1"
        if self.config.settings.get("fsync", True):
            env["WINEFSYNC"] = "1"
        if self.config.settings.get("dxvk_enabled", True):
            env["DXVK_ASYNC"] = "1"
            
        if runner["type"] == "proton":
            env["STEAM_COMPAT_DATA_PATH"] = str(self.config.data_dir / "proton_compat")
            env["STEAM_COMPAT_CLIENT_INSTALL_PATH"] = str(Path.home() / ".local/share/Steam")
            (self.config.data_dir / "proton_compat").mkdir(parents=True, exist_ok=True)
            
        return env

    def prepare_prefix(self, runner: Dict[str, str]) -> bool:
        p_system = self.config.prefix_dir / "drive_c" / "windows" / "system32"
        if p_system.exists():
            return True
        env = self.get_wine_env(runner)
        try:
            cmd = [runner["path"], "wineboot", "--init"] if runner["type"] == "wine" else [runner["path"], "run", "wineboot", "--init"]
            subprocess.run(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            return True
        except Exception:
            return False

    def launch_game(self, game_key: str, mode: str = "lan", extra_args: Optional[List[str]] = None, log_callback=None) -> int:
        def log(msg):
            if log_callback:
                log_callback(msg)
            else:
                print(msg)

        if game_key not in SUPPORTED_GAMES:
            log(f"[-] Unknown game: {game_key}")
            return 1

        game_info = SUPPORTED_GAMES[game_key]
        game_path = self.config.games.get(game_key)
        if not game_path or not Path(game_path).exists():
            log(f"[-] Game folder not configured for {game_info['title']}.")
            return 1

        runner = RunnerManager.get_best_runner(self.config.settings.get("runner_type", "auto"))
        if not runner:
            log("[-] No Wine or Proton runner found! Please install Wine or Steam Proton.")
            return 1

        log(f"[+] Active Runner: {runner['name']}")
        self.prepare_prefix(runner)
        env = self.get_wine_env(runner)
        game_dir = Path(game_path)

        if mode == "plutonium":
            self.download_plutonium_exe()
            exe_path = self.config.plutonium_dir / "plutonium.exe"
            if not exe_path.exists():
                log(f"[-] Plutonium.exe not found at {exe_path}")
                return 1
            log(f"[*] Starting Plutonium launcher for {game_info['title']}...")
            launch_cmd = [runner["path"]]
            if runner["type"] == "proton":
                launch_cmd += ["run"]
            launch_cmd += [str(exe_path)]
            if extra_args:
                launch_cmd += extra_args
        else:
            target_exe = None
            for e in game_info["exe_names"]:
                if (game_dir / e).exists():
                    target_exe = game_dir / e
                    break
            if not target_exe:
                log(f"[-] Executable not found in {game_dir}. Checked: {game_info['exe_names']}")
                return 1

            log(f"[+] Launching {game_info['title']} directly in Safe LAN Mode...")
            launch_cmd = [runner["path"]]
            if runner["type"] == "proton":
                launch_cmd += ["run"]
            launch_cmd += [str(target_exe)]

            default_game_args = ["+set", "sv_lan", "1", "+set", "party_maxplayers", "18"]
            if game_info["game_id"] == "t6":
                default_game_args += ["+set", "onlinegame", "0", "+set", "zombies", "1" if game_info["mode"] == "zm" else "0"]
            if extra_args:
                launch_cmd += extra_args
            else:
                launch_cmd += default_game_args

        try:
            self.active_process = subprocess.Popen(launch_cmd, env=env, cwd=str(game_dir), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in self.active_process.stdout:
                log(line.strip())
            self.active_process.wait()
            ret = self.active_process.returncode
            self.active_process = None
            log(f"[+] Game process exited with return code {ret}")
            return ret
        except Exception as e:
            log(f"[-] Execution error: {e}")
            self.active_process = None
            return 1

    def kill_active_game(self) -> bool:
        if self.active_process:
            try:
                self.active_process.terminate()
                return True
            except Exception:
                pass
        return False

class ServerBrowser:
    @staticmethod
    def fetch_servers() -> List[dict]:
        try:
            req = urllib.request.Request(
                PLUTONIUM_API_URL,
                headers={"User-Agent": "PlutoniumLinuxClient/1.4"}
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data if isinstance(data, list) else data.get("servers", [])
        except Exception:
            return []

class DesktopIntegration:
    @staticmethod
    def create_desktop_shortcut(game_key: str):
        if game_key not in SUPPORTED_GAMES:
            return
        info = SUPPORTED_GAMES[game_key]
        apps_dir = Path.home() / ".local" / "share" / "applications"
        apps_dir.mkdir(parents=True, exist_ok=True)
        desktop_file = apps_dir / f"plutonium-{game_key}.desktop"
        
        content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=Plutonium: {info['title']}
Comment={info['description']}
Exec=/usr/bin/plutonium-client launch {game_key} --mode lan
Icon=plutonium-linux-client
Terminal=false
Categories=Game;ActionGame;
Keywords=Call of Duty;Plutonium;BO2;MW3;WaW;Zombies;
StartupNotify=false
"""
        with open(desktop_file, "w", encoding="utf-8") as f:
            f.write(content)
        desktop_file.chmod(0o755)

# ==============================================================================
# Native GTK 3 Desktop GUI Window
# ==============================================================================

def launch_gtk3_gui(config: LinuxClientConfig) -> bool:
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk, Gdk, GLib
    except Exception as e:
        print(f"[-] PyGObject/GTK 3 not available: {e}")
        return False

    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        print("[-] Graphical display server not found ($DISPLAY or $WAYLAND_DISPLAY not set).")
        return False

    try:
        Gtk.init()
    except Exception as e:
        print(f"[-] Gtk.init error: {e}")
        return False

    def create_label(text="", markup=None, halign=None, wrap=False):
        lbl = Gtk.Label()
        if markup:
            lbl.set_markup(markup)
        elif text:
            lbl.set_text(text)
        if halign:
            lbl.set_halign(halign)
        if wrap:
            lbl.set_line_wrap(True)
        return lbl

    pm = PlutoniumManager(config)

    class PlutoniumGtkWindow(Gtk.Window):
        def __init__(self, cfg: LinuxClientConfig):
            super().__init__()
            self.config = cfg
            self.set_title("Plutonium Linux Client")
            self.set_default_size(1080, 680)
            self.set_position(Gtk.WindowPosition.CENTER)

            self.current_game = "t6zm"
            self.selected_mode = "lan"
            self.server_cache = []

            # Dark theme CSS
            try:
                css_provider = Gtk.CssProvider()
                css = b"""
                window { background-color: #121316; color: #f0f0f0; }
                .sidebar { background-color: #181920; border-right: 1px solid #2e313d; }
                .game-btn {
                    padding: 12px 14px; border: none; background: transparent;
                    color: #a0a3b0; font-weight: bold; border-radius: 6px; margin: 3px 6px;
                }
                .game-btn:hover { background-color: #262936; color: #ffffff; }
                .game-btn-active { background-color: #ff6f00; color: #ffffff; }
                .content-pane { padding: 24px; background-color: #121316; }
                .hero-card {
                    background-color: #1e2029; border-radius: 10px; padding: 22px;
                    border: 1px solid #2e313d;
                }
                .play-btn {
                    background-color: #ff6f00; color: white; font-weight: 800; font-size: 16px;
                    padding: 12px 36px; border-radius: 8px; border: none;
                }
                .play-btn:hover { background-color: #ff8c00; }
                .stop-btn {
                    background-color: #c62828; color: white; font-weight: 700;
                    padding: 10px 20px; border-radius: 8px; border: none;
                }
                .stop-btn:hover { background-color: #d32f2f; }
                .sub-btn {
                    background-color: #2b2e3b; color: #e0e0e0; padding: 8px 16px;
                    border-radius: 6px; border: none;
                }
                .sub-btn:hover { background-color: #373b4b; }
                """
                css_provider.load_from_data(css)
                screen = Gdk.Screen.get_default()
                if screen:
                    Gtk.StyleContext.add_provider_for_screen(screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            except Exception:
                pass

            main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
            self.add(main_box)

            # Sidebar
            sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            sidebar.get_style_context().add_class("sidebar")
            sidebar.set_size_request(270, -1)
            main_box.pack_start(sidebar, False, False, 0)

            title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            title_box.set_margin_top(18)
            title_box.set_margin_bottom(18)
            title_box.set_margin_start(16)
            title_box.set_margin_end(16)
            title_box.pack_start(create_label(markup="<span size='large' weight='heavy' color='#ff6f00'>PLUTONIUM</span> <span size='small' color='#aaa'>LINUX</span>", halign=Gtk.Align.START), False, False, 0)
            sidebar.pack_start(title_box, False, False, 0)

            self.game_buttons = {}
            for g_key, g_info in SUPPORTED_GAMES.items():
                stitle = g_info["title"].replace("Call of Duty: ", "")
                btn = Gtk.Button(label=stitle)
                btn.get_style_context().add_class("game-btn")
                btn.connect("clicked", self.on_select_game, g_key)
                sidebar.pack_start(btn, False, False, 0)
                self.game_buttons[g_key] = btn

            sidebar.pack_start(Gtk.Box(), True, True, 0)

            scan_btn = Gtk.Button(label="🔍 Auto-Scan Steam Games")
            scan_btn.get_style_context().add_class("sub-btn")
            scan_btn.set_margin_bottom(16)
            scan_btn.set_margin_start(12)
            scan_btn.set_margin_end(12)
            scan_btn.connect("clicked", self.on_scan_steam)
            sidebar.pack_start(scan_btn, False, False, 0)

            # Main Notebook
            self.notebook = Gtk.Notebook()
            main_box.pack_start(self.notebook, True, True, 0)

            # Tab 1: Game Launcher
            self.tab_launch = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
            self.tab_launch.get_style_context().add_class("content-pane")
            self.build_launcher_tab()
            self.notebook.append_page(self.tab_launch, create_label(text="Game Launcher"))

            # Tab 2: Server Browser
            self.tab_servers = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            self.tab_servers.get_style_context().add_class("content-pane")
            self.build_servers_tab()
            self.notebook.append_page(self.tab_servers, create_label(text="Server Browser"))

            # Tab 3: Settings
            self.tab_settings = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
            self.tab_settings.get_style_context().add_class("content-pane")
            self.build_settings_tab()
            self.notebook.append_page(self.tab_settings, create_label(text="Settings & Runners"))

            self.update_display()

        def build_launcher_tab(self):
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            card.get_style_context().add_class("hero-card")
            self.tab_launch.pack_start(card, False, False, 0)

            self.lbl_title = create_label(halign=Gtk.Align.START)
            card.pack_start(self.lbl_title, False, False, 0)

            self.lbl_desc = create_label(halign=Gtk.Align.START, wrap=True)
            card.pack_start(self.lbl_desc, False, False, 0)

            path_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            self.lbl_path = create_label(halign=Gtk.Align.START)
            path_row.pack_start(self.lbl_path, True, True, 0)

            browse_btn = Gtk.Button(label="📁 Browse Folder")
            browse_btn.get_style_context().add_class("sub-btn")
            browse_btn.connect("clicked", self.on_browse_folder)
            path_row.pack_start(browse_btn, False, False, 0)

            open_btn = Gtk.Button(label="Open in Files")
            open_btn.get_style_context().add_class("sub-btn")
            open_btn.connect("clicked", self.on_open_game_folder)
            path_row.pack_start(open_btn, False, False, 0)
            card.pack_start(path_row, False, False, 0)

            mode_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            self.r_lan = Gtk.RadioButton.new_with_label(None, "🛡️ LAN / Offline Safe Mode (Recommended: Zero Anti-Cheat Ban Risk, Full Bots & Zombies)")
            self.r_online = Gtk.RadioButton.new_with_label_from_widget(self.r_lan, "🌐 Official Plutonium Launcher (Runs plutonium.exe updater with Wine)")
            self.r_lan.connect("toggled", lambda b: setattr(self, "selected_mode", "lan") if b.get_active() else None)
            self.r_online.connect("toggled", lambda b: setattr(self, "selected_mode", "plutonium") if b.get_active() else None)
            mode_box.pack_start(self.r_lan, False, False, 0)
            mode_box.pack_start(self.r_online, False, False, 0)
            card.pack_start(mode_box, False, False, 0)

            args_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            args_row.pack_start(create_label(text="Launch Parameters:"), False, False, 0)
            self.entry_args = Gtk.Entry()
            args_row.pack_start(self.entry_args, True, True, 0)
            card.pack_start(args_row, False, False, 0)

            act_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
            self.btn_play = Gtk.Button(label="▶ PLAY NOW")
            self.btn_play.get_style_context().add_class("play-btn")
            self.btn_play.connect("clicked", self.on_play)
            act_row.pack_start(self.btn_play, False, False, 0)

            self.btn_stop = Gtk.Button(label="⏹ Stop Game")
            self.btn_stop.get_style_context().add_class("stop-btn")
            self.btn_stop.set_sensitive(False)
            self.btn_stop.connect("clicked", self.on_stop)
            act_row.pack_start(self.btn_stop, False, False, 0)

            desk_btn = Gtk.Button(label="Create Desktop Shortcut")
            desk_btn.get_style_context().add_class("sub-btn")
            desk_btn.connect("clicked", lambda b: DesktopIntegration.create_desktop_shortcut(self.current_game))
            act_row.pack_start(desk_btn, False, False, 0)
            card.pack_start(act_row, False, False, 0)

            # Console output
            log_frame = Gtk.Frame(label="Launcher Output Console")
            self.log_buf = Gtk.TextBuffer()
            tv = Gtk.TextView(buffer=self.log_buf)
            tv.set_editable(False)
            scrolled = Gtk.ScrolledWindow()
            scrolled.set_min_content_height(140)
            scrolled.add(tv)
            log_frame.add(scrolled)
            self.tab_launch.pack_start(log_frame, True, True, 0)

        def build_servers_tab(self):
            bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            ref_btn = Gtk.Button(label="🔄 Refresh Live Servers")
            ref_btn.get_style_context().add_class("sub-btn")
            ref_btn.connect("clicked", self.on_refresh_servers)
            bar.pack_start(ref_btn, False, False, 0)

            bar.pack_start(create_label(text="Filter:"), False, False, 0)
            self.entry_filter = Gtk.Entry()
            self.entry_filter.connect("changed", self.on_filter_changed)
            bar.pack_start(self.entry_filter, False, False, 0)

            self.lbl_server_status = create_label(text="Click Refresh to load master servers")
            bar.pack_start(self.lbl_server_status, False, False, 0)
            self.tab_servers.pack_start(bar, False, False, 0)

            self.server_store = Gtk.ListStore(str, str, str, str, str)
            tree = Gtk.TreeView(model=self.server_store)
            for i, c in enumerate(["Game", "Players", "Map", "Server Name", "IP:Port"]):
                col = Gtk.TreeViewColumn(c, Gtk.CellRendererText(), text=i)
                col.set_resizable(True)
                if i == 3:
                    col.set_min_width(320)
                tree.append_column(col)
            scrolled = Gtk.ScrolledWindow()
            scrolled.add(tree)
            self.tab_servers.pack_start(scrolled, True, True, 0)

        def build_settings_tab(self):
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
            card.get_style_context().add_class("hero-card")
            self.tab_settings.pack_start(card, False, False, 0)

            card.pack_start(create_label(markup="<span size='large' weight='bold' color='#ff6f00'>Runner & System Configuration</span>", halign=Gtk.Align.START), False, False, 0)

            runner = RunnerManager.get_best_runner(self.config.settings.get("runner_type", "auto"))
            r_name = runner["name"] if runner else "None Detected"
            card.pack_start(create_label(markup=f"<b>Detected Active Runner:</b> {r_name}", halign=Gtk.Align.START), False, False, 0)
            card.pack_start(create_label(markup=f"<b>Wine Prefix Path:</b> {self.config.prefix_dir}", halign=Gtk.Align.START), False, False, 0)

            dxvk_chk = Gtk.CheckButton(label="Enable DXVK Direct3D-to-Vulkan translation layer")
            dxvk_chk.set_active(self.config.settings.get("dxvk_enabled", True))
            card.pack_start(dxvk_chk, False, False, 0)

            esync_chk = Gtk.CheckButton(label="Enable Esync high-performance thread synchronization")
            esync_chk.set_active(self.config.settings.get("esync", True))
            card.pack_start(esync_chk, False, False, 0)

            act_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            open_p_btn = Gtk.Button(label="📂 Open Wineprefix Folder")
            open_p_btn.get_style_context().add_class("sub-btn")
            open_p_btn.connect("clicked", lambda b: subprocess.Popen(["xdg-open", str(self.config.prefix_dir)]))
            act_row.pack_start(open_p_btn, False, False, 0)
            card.pack_start(act_row, False, False, 0)

        def log(self, text: str):
            GLib.idle_add(lambda: self.log_buf.insert(self.log_buf.get_end_iter(), text + "\n"))

        def on_select_game(self, btn, g_key):
            self.current_game = g_key
            self.update_display()

        def update_display(self):
            info = SUPPORTED_GAMES[self.current_game]
            for k, b in self.game_buttons.items():
                if k == self.current_game:
                    b.get_style_context().add_class("game-btn-active")
                else:
                    b.get_style_context().remove_class("game-btn-active")

            self.lbl_title.set_markup(f"<span size='x-large' weight='heavy' color='#ff6f00'>{info['title']}</span>")
            self.lbl_desc.set_markup(f"<span color='#b0b3b8'>{info['description']}</span>")

            p = self.config.games.get(self.current_game)
            if p and Path(p).exists():
                self.lbl_path.set_markup(f"<span color='#00e676'>✓ Installed:</span> <span color='#aaa'>{p}</span>")
                self.btn_play.set_sensitive(True)
            else:
                self.lbl_path.set_markup("<span color='#ff5252'>✗ Folder not set. Click 'Browse Folder' or 'Auto-Scan Steam'.</span>")
                self.btn_play.set_sensitive(False)

        def on_browse_folder(self, btn):
            d = Gtk.FileChooserDialog(title="Select Game Folder", parent=self, action=Gtk.FileChooserAction.SELECT_FOLDER)
            d.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK)
            if d.run() == Gtk.ResponseType.OK:
                chosen = d.get_filename()
                self.config.games[self.current_game] = chosen
                self.config.save_games()
                self.log(f"[+] Configured {self.current_game} -> {chosen}")
                self.update_display()
            d.destroy()

        def on_open_game_folder(self, btn):
            p = self.config.games.get(self.current_game)
            if p and Path(p).exists():
                subprocess.Popen(["xdg-open", p])

        def on_scan_steam(self, btn):
            self.log("[*] Scanning Steam libraries...")
            found = GameDiscovery.auto_detect_games()
            for k, p in found.items():
                self.config.games[k] = p
                self.log(f"[+] Found {k}: {p}")
            self.config.save_games()
            self.update_display()

        def on_play(self, btn):
            g = self.current_game
            m = self.selected_mode
            args = self.entry_args.get_text().split() if self.entry_args.get_text().strip() else None
            self.btn_play.set_sensitive(False)
            self.btn_stop.set_sensitive(True)
            self.log(f"[*] Starting {g} ({m.upper()})...")
            def worker():
                pm.launch_game(g, mode=m, extra_args=args, log_callback=self.log)
                GLib.idle_add(lambda: self.btn_play.set_sensitive(True))
                GLib.idle_add(lambda: self.btn_stop.set_sensitive(False))
            threading.Thread(target=worker, daemon=True).start()

        def on_stop(self, btn):
            if pm.kill_active_game():
                self.log("[!] Force terminated game process.")

        def on_filter_changed(self, entry):
            q = entry.get_text().lower()
            self.server_store.clear()
            for s in self.server_cache:
                game = s.get("game", "N/A")
                cur_p = str(s.get("players", len(s.get("players_list", []))))
                max_p = str(s.get("maxplayers", s.get("max_players", 18)))
                pmap = s.get("map", "unknown")
                cname = "".join(c for i, c in enumerate(s.get("hostname", s.get("name", ""))) if not (c == '^' or (i > 0 and s.get("hostname", s.get("name", ""))[i-1] == '^')))[:45]
                conn = f"{s.get('ip','127.0.0.1')}:{s.get('port', 4976)}"
                if q and q not in game.lower() and q not in pmap.lower() and q not in cname.lower():
                    continue
                self.server_store.append([game, f"{cur_p}/{max_p}", pmap[:15], cname, conn])

        def on_refresh_servers(self, btn):
            self.lbl_server_status.set_text("Fetching servers...")
            def fetch():
                self.server_cache = ServerBrowser.fetch_servers()
                GLib.idle_add(lambda: self.on_filter_changed(self.entry_filter))
                GLib.idle_add(lambda: self.lbl_server_status.set_text(f"Loaded {len(self.server_cache)} servers."))
            threading.Thread(target=fetch, daemon=True).start()

    try:
        win = PlutoniumGtkWindow(config)
        win.connect("destroy", Gtk.main_quit)
        win.show_all()
        Gtk.main()
        return True
    except Exception as e:
        print(f"[-] GTK Window startup error: {e}")
        traceback.print_exc()
        try:
            with open("/tmp/plutonium-error.log", "w") as f:
                traceback.print_exc(file=f)
        except Exception:
            pass
        return False

def print_help():
    print(f"""
Plutonium Linux Client (v{VERSION})
====================================
Usage: plutonium-client [command] [options]

When run without arguments: Opens the Desktop GUI Application.

Commands:
  gui                    Launch the desktop GUI window
  scan                   Scan system for installed CoD games
  status                 Show status of configured games and runners
  launch <game>          Launch a game (--mode lan or --mode online)
  servers [game]         Query live servers
  desktop <game>         Create desktop application shortcut
""")

def main():
    config = LinuxClientConfig()
    pm = PlutoniumManager(config)

    if len(sys.argv) < 2 or sys.argv[1].lower() == "gui":
        if not launch_gtk3_gui(config):
            print("[-] Could not start desktop GUI. Please run in terminal to inspect logs:")
            print("    plutonium-client")
        return 0

    cmd = sys.argv[1].lower()
    if cmd in ("-h", "--help", "help"):
        print_help()
        return 0
    elif cmd == "scan":
        detected = GameDiscovery.auto_detect_games()
        for g, p in detected.items():
            config.games[g] = p
        config.save_games()
        print(f"[+] Found {len(detected)} games: {detected}")
    elif cmd == "status":
        print(f"Config: {config.config_dir}")
        print(f"Games: {config.games}")
    elif cmd == "launch":
        g = sys.argv[2].lower()
        mode = "lan"
        if "--mode" in sys.argv:
            idx = sys.argv.index("--mode")
            if idx + 1 < len(sys.argv):
                mode = sys.argv[idx + 1].lower()
        return pm.launch_game(g, mode=mode)
    elif cmd == "desktop":
        DesktopIntegration.create_desktop_shortcut(sys.argv[2].lower())
    else:
        print_help()
    return 0

if __name__ == "__main__":
    sys.exit(main())